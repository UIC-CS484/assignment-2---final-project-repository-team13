# TEAM'S MEMBERS:

```
Tru Nguyen, Umer Qazi, Marko Glamocak
```

United Test have already been created:
1. rough draft of backend testing

Unit Test plan:
1. Do unit testing with pupetteer to mimc the user's behavior
2. Do extensive unit testing for backend.

The test above cover all aspect of user wise, because we mimic the behavior through chrome, and we also do backend testing to ensure that no vulnerability exist.